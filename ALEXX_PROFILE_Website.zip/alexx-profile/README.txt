# ALEXX PROFILE

A lightweight, responsive personal profile website with a bright white floral-inspired glass design.

## Preview locally
1. Extract the ZIP.
2. Open the `alexx-profile` folder.
3. Double-click `index.html` to preview in a browser.

For best results, run it with a local static server (for example, VS Code Live Server).

## Publish online
This is a static website and can be hosted on GitHub Pages, Netlify, or Vercel:
1. Create an account with your chosen hosting provider.
2. Upload the contents of this folder (the `index.html` file and `assets` folder).
3. Deploy as a static site with no build command.
4. Copy the public HTTPS URL after deployment.
5. Put that URL in your Instagram/Discord bio.

The public URL does not exist until you deploy it. I cannot publish to your hosting account from this file.

## Included links
- Discord: https://discord.com/users/1492376391881068615
- Instagram: https://www.instagram.com/alexx9778_/
- Music: https://youtu.be/4MRX18Pzkjw

The YouTube player loads only after a visitor clicks Play. The track is embedded from YouTube; it is not downloaded or re-hosted.
